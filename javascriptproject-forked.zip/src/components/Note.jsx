import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>
        {" "}
        This is amazing bootcamp taken up Shaurya sir. We covered everything
        from Scratch including Javascript react.js, HTML.
      </p>
    </div>
  );
}
export default Note;
